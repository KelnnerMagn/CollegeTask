package br.SteamPOO;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import static br.SteamPOO.CategoriaDeJogo.*;

class SteamPOOHashTest {

	@Test
	void testCadastraJogo() {
		SteamPOOHash sistema = new SteamPOOHash();
		Jogo jogo = new Jogo("Zelda");
		jogo.adicionaCategoria(ARCADE);
		assertDoesNotThrow(() -> sistema.cadastraJogo(jogo));
		assertTrue(sistema.existeJogoComNome("Zelda"));
		assertTrue(sistema.contaJogosDaCategoria(ARCADE) == 1);
		assertDoesNotThrow(() -> assertTrue(sistema.pesquisaPrecoDoJogo("Zelda") == 0.0));
	}
	
	@Test
	void testPesquisaJogo() {
		SteamPOOHash sistema = new SteamPOOHash();
		assertDoesNotThrow(()-> {
			sistema.cadastraJogo(new Jogo("mario"));
			sistema.pesquisaJogo("mario").adicionaCategoria(AVENTURA);
		});
		assertThrows(JogoInexistenteException.class, () -> sistema.pesquisaJogo("alfredo"));
	}

	@Test
	void testAdicionaCategoriaEmJogo() {
		SteamPOOHash sistema = new SteamPOOHash();
		assertDoesNotThrow(()-> {
			sistema.cadastraJogo(new Jogo("Apex"));
			sistema.adicionaCategoriaEmJogo("Apex", ACAO);
		});
		assertThrows(JogoInexistenteException.class,
				() -> sistema.adicionaCategoriaEmJogo("Rainbow", ACAO));
	}

}
