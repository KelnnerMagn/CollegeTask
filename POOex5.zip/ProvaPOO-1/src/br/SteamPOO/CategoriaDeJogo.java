package br.SteamPOO;

public enum CategoriaDeJogo {

	AVENTURA, TERROR, ARCADE, GUERRA, CORRIDA, ACAO, LUTA
}
