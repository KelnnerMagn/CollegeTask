package br.SteamPOO;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


public class SteamGUI extends JFrame{

	private static final long serialVersionUID = -7224102697805540668L;
	
	JLabel linha1, linha2, linha3;
	ImageIcon addImg = new ImageIcon("./add.png");
	ImageIcon searchImg = new ImageIcon("./seach.png");
	ImageIcon removeImg = new ImageIcon("./remove.png");
	JButton addButton, searchButton, removeButton;
	SteamPOOHash sistema = new SteamPOOHash();
	
	public SteamGUI() {
		setTitle("Steam");
		setSize(500, 350);
		setLocation(200,200);
		setResizable(false);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		linha1 = new JLabel("Steam", JLabel.LEFT);
		linha1.setForeground(Color.GRAY);
		linha1.setFont(new Font("Arial", Font.BOLD,24));
		linha2 = new JLabel();
		linha3 = new JLabel();
		this.setLayout(new GridLayout(3,2));
		addButton = new JButton("Adicionar", addImg);
		addButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String nome = JOptionPane.showInputDialog(this, "Diga o nome do jogo: ");
				try {
					sistema.cadastraJogo(new Jogo(nome));
					JOptionPane.showInputDialog(this, "O cadastro foi um sucesso");
				} catch (JogoJaExisteException e1) {
					JOptionPane.showInputDialog(this, "O cadastro Falhou");
				}
			}
		});
		searchButton = new JButton("Pesquisar", searchImg);
		searchButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String NomePesquisar = JOptionPane.showInputDialog(this,
						"Digite o nome do jogo que deseja pesqusiar: ");
				try {
					Jogo j = sistema.pesquisaJogo(NomePesquisar);
					JOptionPane.showInputDialog(this, j.getNome() + ", foi encontrado");
				} catch (JogoInexistenteException e1) {
					JOptionPane.showInputDialog(this, "O jogo que voc� pesquisou n�o existe");
				}
			}
		});
		removeButton = new JButton("Remover", removeImg);
		removeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String nome = JOptionPane.showInputDialog(this,
						"Digite o nome do jogo que deseja remover: ");
				try {
					sistema.removerJogo(nome);
					JOptionPane.showInputDialog(this, "O jogo foi removido com sucesso");
				} catch (JogoInexistenteException e1) {
					JOptionPane.showInputDialog(this, "Jogo n�o encontrado");
				}
			}
		});
		this.add(linha1);
		this.add(addButton);
		this.add(linha2);
		this.add(searchButton);
		this.add(linha3);
		this.add(removeButton);		
		
	}
	
	public static void main (String [] args) {
		JFrame janela = new SteamGUI();
		janela.setVisible(true);
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
}
