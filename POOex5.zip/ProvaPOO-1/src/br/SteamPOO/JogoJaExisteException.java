package br.SteamPOO;

public class JogoJaExisteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public JogoJaExisteException(String msg) {
		super(msg);
	}

}
