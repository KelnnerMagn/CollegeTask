package br.SteamPOO;

public class JogoInexistenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public JogoInexistenteException(String msg) {
		super(msg);
	}

}
