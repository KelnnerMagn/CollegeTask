package br.SteamPOO;

import java.util.ArrayList;
import java.util.List;

public class Jogo {

    private String nome;
    private double preco;
    private List<CategoriaDeJogo> categorias;

    public Jogo(String nome, double preco, List<CategoriaDeJogo> categorias) {
        this.nome = nome;
        this.preco = preco;
        this.categorias = categorias;
    }
    
    public Jogo(String nome) {
        this.nome = nome;
        this.preco = 0.0;
        this.categorias = new ArrayList<>();
    }

    public boolean adicionaCategoria(CategoriaDeJogo categoria) {
    	if (!this.categorias.contains(categoria)) {
    		this.categorias.add(categoria);
    		return true;
    	} else {
    		return false;
    	}
    }
    
    

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}
    
    public List<CategoriaDeJogo> getCategorias(){
    	return this.categorias;
    }
    
    public void setCategorias(List<CategoriaDeJogo> categorias) {
    	this.categorias = categorias;
    }
    
    public boolean ehDaCategoria(CategoriaDeJogo categoria) {
    	if(this.categorias.contains(categoria)) {
    		return true;
    	}else {
    		return false;
    	}
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((categorias == null) ? 0 : categorias.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		long temp;
		temp = Double.doubleToLongBits(preco);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Jogo other = (Jogo) obj;
		if (categorias == null) {
			if (other.categorias != null)
				return false;
		} else if (!categorias.equals(other.categorias))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (Double.doubleToLongBits(preco) != Double.doubleToLongBits(other.preco))
			return false;
		return true;
	}
    
    
}
